import os
import sys
from pathlib import Path
import torch

FILE = Path(__file__).resolve()  # 设置根目录，确保路径正确
ROOT = FILE.parents[0]  
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT)) 
ROOT = Path(os.path.relpath(ROOT, Path.cwd()))  

from ultralytics.utils.plotting import Annotator, colors, save_one_box

from models.common import DetectMultiBackend
from utils.dataloaders import IMG_FORMATS, VID_FORMATS, LoadImages, LoadScreenshots, LoadStreams
from utils.general import (LOGGER,Profile,check_file,check_img_size,check_imshow,check_requirements,
    colorstr,cv2,increment_path,non_max_suppression,print_args,scale_boxes,strip_optimizer,xyxy2xywh,)
from utils.torch_utils import select_device, smart_inference_mode


class YOLOv5:   #只将常需要更换的值设为形参，方便更改，把一些不怎么需要更换的放在内部。
    def __init__(self, weights='yolov5s.pt', source=ROOT / "data/images", data=ROOT / "data/coco128.yaml", ): 
        self.weights = weights      #权重
        self.source = str(source)   #图片来源
        self.data = data            #图片标记数据
        self.device=select_device("")   #选择gpu或cpu
        self.imgsz = (640,640)      #图框大小
        self.conf_thres = 0.25      #置信度
        self.iou_thres = 0.45       
        self.vid_stride=1           #步长
        self.classes =None          
        self.agnostic_nms=False
        self.max_det=1000           #单次最大线框数
        self.visualize = False      #是否保存推理过程
        self.augment=False          #是否加强推理
        self.line_thickness = 3     #线框的粗细
        self.project=ROOT / "runs/detect"
        self.save_img = True         #是否保存
        
    #只进行图片的推断，所以不用对source源进行判断
    def load(self):  #进行数据和模型的加载
        self.model = DetectMultiBackend(self.weights, device=self.device, dnn=False, data=self.data, fp16=False)
        self.stride, self.names, self.pt = self.model.stride, self.model.names, self.model.pt
        self.imgsz = check_img_size(self.imgsz, s=self.stride)
        self.dataset = LoadImages(self.source, img_size=self.imgsz, stride=self.stride, auto=self.pt, vid_stride=self.vid_stride)
        self.bs = 1
        self.save_dir = increment_path(Path(self.project) / "exp", exist_ok=False)  #确定保存目录
        self.save_dir.mkdir(parents=True, exist_ok=True)  # 生成保存目录

    def process(self,im,pred,path,im0s,target):
        for i, det in enumerate(pred):  # 从每幅图里取
                self.detected_flag = False
                self.seen += 1
                p,im0 = path, im0s.copy()
                self.s += f"{i}: "
                p = Path(p)
                save_path = str(self.save_dir / p.name)  # im.jpg
                #LOGGER.info(f"Save path: {save_path}")
                self.s += "{:g}x{:g} ".format(*im.shape[2:])  # 将图片数据记入s中
                annotator = Annotator(im0, line_width=self.line_thickness, example=str(self.names))
                if len(det):
                    #将框的坐标映射回原图坐标
                    det[:, :4] = scale_boxes(im.shape[2:],det[:, :4], im0.shape).round()
                    # Print results
                    for c in det[:, 5].unique():
                        n = (det[:, 5] == c).sum()  # 存在的类别
                        if c == target:
                            self.detected_flag = True
                        self.s += f"{n} {self.names[int(c)]}{'s' * (n > 1)}, "  # 添加打印数据
                    for *xyxy, conf, cls in reversed(det):
                        if self.save_img :  # 画框框
                            c = int(cls)  # integer class
                            label = f"{self.names[c]} {conf:.2f}"
                            annotator.box_label(xyxy, label, color=colors(c, True))
                im0 = annotator.result()
                if self.save_img:
                    if self.dataset.mode == "image":
                        cv2.imwrite(save_path,im0)

    def run_inference(self,target): #开始进行推演
        self.model.warmup(imgsz=(1 if self.pt or self.model.triton else self.bs, 3, *self.imgsz))   #预热，丢空白图片跑一下
        self.seen,self.dt = 0,(Profile(device=self.device), Profile(device=self.device), Profile(device=self.device))#初始化一些变量
        #对数据进行预处理
        for path, im, im0s, self.vid_cap, self.s in self.dataset:
            with self.dt[0]:  #dt是用来计算时间的一个管理器
                im = torch.from_numpy(im).to(self.model.device)  #将numpy转为张量
                im = im.half() if self.model.fp16 else im.float()  # 确定图像的精度
                im /= 255  # 将图像的像素值归一化
                if len(im.shape) == 3:
                    im = im[None]  # 将图片的bs数据加进列表
            # 开始推理
            with self.dt[1]:
                visualize = increment_path(self.save_dir / Path(path).stem, mkdir=True) if self.visualize else False  #判断是否要将结果可视化
                pred = self.model(im, augment=self.augment, visualize=visualize)#此时会得到很多的框
            print(f"Inference{self.seen+1} time: {self.dt[1].dt * 1e3:.2f} ms with ")
            #进行后处理，对得到的框进行非极大值抑制，按要求筛选
            with self.dt[2]:
                pred = non_max_suppression(pred, self.conf_thres, self.iou_thres, self.classes, self.agnostic_nms, max_det=self.max_det)
            self.process(im,pred,path,im0s,target)
            print(f"Detected target class {target}:{self.detected_flag}")
        LOGGER.info(f"Results saved to {colorstr('bold', self.save_dir)}")

    @smart_inference_mode()
    def run(self,target):
        self.load()
        self.run_inference(target)

def main():
    check_requirements(ROOT / "requirements.txt", exclude=("tensorboard", "thop"))
    target= 0 #设置标志位，用来判断是否检测到某类
    yolo=YOLOv5() #如果想要更改数据或模型可以在这更改
    yolo.run(target)
    
if __name__ == "__main__":
    main()
    